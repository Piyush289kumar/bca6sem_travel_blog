<?php
include("../config.php");
echo "<script>window.location.href='$hostname'</script>";
