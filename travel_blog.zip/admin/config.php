<?php
$website_display_default_name = "Travel Blog";
$hostname = "http://localhost/travel_blog";
$conn = mysqli_connect('localhost', 'root', '', 'travel_blog_db') or die("Connection Failed!!" . mysqli_connect_error());