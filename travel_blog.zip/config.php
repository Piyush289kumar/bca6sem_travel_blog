<?php
$website_display_default_name = "Travel Blog";
// $hostname = "http://localhost/travel_blog";
$hostname = "cibadress.com/app/bca6sem/trave_blog";
$conn = mysqli_connect('localhost', 'root', '', 'travel_blog_db') or die("Connection Failed!!" . mysqli_connect_error());
// $conn = mysqli_connect('localhost', 'u423777452_travel_blog_db', 'Piyush@289', 'u423777452_travel_blog') or die("Connection Failed!!" . mysqli_connect_error());
